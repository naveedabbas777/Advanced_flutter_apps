package com.example.student_management_cursor

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
